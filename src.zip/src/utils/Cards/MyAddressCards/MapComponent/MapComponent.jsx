import React from 'react'

const MapComponent = () => {
  return (
    <div>MapComponent</div>
  )
}

export default MapComponent