export const orderOnlinePage = 'order-online';
export const diningOutPage = 'dinning-out';
export const proAndProPlusPage = 'pro-and-pro-plus';
export const nightLifePage = 'night-life';

export const reviewPage = 'reviews'
export const photosPage = 'photos'
export const followersPage = 'followers'
export const recentlyviewedPage = 'recently-viewed'
export const bookmarksPage = 'bookmarks'
export const blogpostsPage = 'blog-posts'
export const orderhistoryPage = 'order-history'
export const myaddressPage = 'my-address'
export const favoriteordersPage = 'favorite-orders'
export const bookingsPage = 'bookings'